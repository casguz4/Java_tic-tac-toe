/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capstone;

import java.net.URL;
import java.util.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

/**
 *
 * @author Cas Guzdziol, Martti Guillermo, Matt Price - Proj4 Capstone
 */
public class FXMLDocumentController implements Initializable 
{
   // Constants for Columns & Rows in arrays
    public static final int MAX_ROWS = 3;
    public static final int MAX_COLS = 3;
    
    public Label[][] mapLabel = new Label[MAX_ROWS][MAX_COLS];    

    private char mapData[][] = new char[MAX_ROWS][MAX_COLS];
    
    int count = 0;
    //random input    
    Random random =  new Random();
    //user and computer 
    private static String user, computer;
    
    @FXML
    private Button startGame, restartGame, showLastGame;
    @FXML
    private GridPane myGrid;
    @FXML
    private Label userLabel, computerLabel, statusLabel, turnLabel;
    
    //image views for 3x3
    @FXML
    private Label label_r0c0;
    @FXML
    private Label label_r0c1;
    @FXML
    private Label label_r0c2;
    @FXML
    private Label label_r1c0;
    @FXML
    private Label label_r1c1;
    @FXML
    private Label label_r1c2;
    @FXML
    private Label label_r2c0;
    @FXML
    private Label label_r2c1;
    @FXML
    private Label label_r2c2;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // Initialize the mapArray - which holds the letter codes for each label
        //     Intialize to BLANK's to start out.
            for(int i = 0; i < MAX_ROWS; i++){
                for(int j = 0; j < MAX_COLS; j++){
                    mapData[i][j] = ' ';
                } // end for j
            } // end for i
        
        mapLabel[0][0] = label_r0c0;
        mapLabel[0][1] = label_r0c1;
        mapLabel[0][2] = label_r0c2;
        mapLabel[1][0] = label_r1c0;
        mapLabel[1][1] = label_r1c1;
        mapLabel[1][2] = label_r1c2;
        mapLabel[2][0] = label_r2c0;
        mapLabel[2][1] = label_r2c1;
        mapLabel[2][2] = label_r2c2;
        
    } // end of initialize() method   

    @FXML
    private void onStartGame(MouseEvent event) 
    {
        startGame.setDisable(true);
        restartGame.setDisable(false);
        showLastGame.setDisable(true);
        statusLabel.setText("Status: You are currently playing");
        myGrid.setDisable(false);
        myGrid.setOpacity(1.0);
        getRandomOX();
        if(user != "O"){
            computerMove();
        }
    }// end of onStartGame() method
    
    private void getRandomOX()
    {
        String[] array = new String[2];
        array[0] = "O";
        array[1] = "X";
        
        int randomLetter = (int)(Math.random()*2);
        
        if (array[randomLetter] == "O")
        {
            user = array[0];
            computer = array[1];
            userLabel.setText("You are " + user);
            computerLabel.setText("Computer is " + computer);
            userLetterIsO();
        }//end if
        else
        {
            user = array[1];
            computer = array[0];
            userLabel.setText("You are " + user);
            computerLabel.setText("Computer is " + computer);
            computerLetterIsO();
        }//end else
                    
        //System.out.println("user: " + user + " computer: " + computer);
    }//end of getRandom() method    
        
    private void userLetterIsO(){
        turnLabel.setText("It's YOUR turn");
    }
    
    private void computerLetterIsO(){
        turnLabel.setText("It's COMPUTER'S turn");
    }

    @FXML
    private void userMove(MouseEvent event) {
        Label clickedLabel = (Label) event.getSource();
        if(clickedLabel.getText() == "O" || clickedLabel.getText() == "X"){
            turnLabel.setText("Tile is taken, try again");
        }else{
            clickedLabel.setText(user);
            computerLetterIsO();
           if(checkWin()){
               statusLabel.setText("Game Over, " + user + " Wins!");
               myGrid.setDisable(true);
               myGrid.setOpacity(0.2);
           }else{
               computerMove();
           }
           if(checkCatsGame(count) && !checkWin()){
            statusLabel.setText("It's a Cat's Game!");
            }
        }
    }
    private void computerMove(){
        int row, col;
        row = random.nextInt(3);
        col = random.nextInt(3);
        if(mapLabel[row][col].getText() == "O" || mapLabel[row][col].getText() == "X"){
            do{
                row = random.nextInt(3);
                col = random.nextInt(3);
            }while(mapLabel[row][col].getText() == "O" || mapLabel[row][col].getText() == "X");
        }
        mapLabel[row][col].setText(computer);
        if(checkWin()){
            statusLabel.setText("Game Over, " + computer + " Wins!");
            myGrid.setDisable(true);
            myGrid.setOpacity(0.2);
        }
        if(checkCatsGame(count) && !checkWin()){
            statusLabel.setText("It's a Cat's Game!");
        }
        userLetterIsO();
    }//end computerMove

    @FXML
    private void onRestartGame(MouseEvent event){
        for(int x = 0; x < MAX_ROWS; x++){
            for(int y = 0; y < MAX_COLS; y++){
                mapLabel[x][y].setText("");
            }
        }
        startGame();
    }//onRestartGame
    
    private void startGame(){
        startGame.setDisable(true);
        restartGame.setDisable(false);
        showLastGame.setDisable(true);
        statusLabel.setText("Status: You are currently playing");
        myGrid.setDisable(false);
        myGrid.setOpacity(1.0);
        getRandomOX();
        if(user != "O"){
            computerMove();
        }
    }//end startGame
    
    private boolean checkWin(){
        if(mapLabel[0][0].getText() == "X" && mapLabel[0][1].getText() == "X" && mapLabel[0][2].getText() == "X"){
            return true;
        }else if(mapLabel[1][0].getText() == "X" && mapLabel[1][1].getText() == "X" && mapLabel[1][2].getText() == "X"){
            return true;
        }else if(mapLabel[2][0].getText() == "X" && mapLabel[2][1].getText() == "X" && mapLabel[2][2].getText() == "X"){
            return true;
        }else if(mapLabel[0][0].getText() == "X" && mapLabel[1][0].getText() == "X" && mapLabel[2][0].getText() == "X"){
            return true;
        }else if(mapLabel[0][1].getText() == "X" && mapLabel[1][1].getText() == "X" && mapLabel[2][1].getText() == "X"){
            return true;
        }else if(mapLabel[0][2].getText() == "X" && mapLabel[1][2].getText() == "X" && mapLabel[2][2].getText() == "X"){
            return true;
        }else if(mapLabel[0][0].getText() == "X" && mapLabel[1][1].getText() == "X" && mapLabel[2][2].getText() == "X"){
            return true;
        }else if(mapLabel[0][2].getText() == "X" && mapLabel[1][1].getText() == "X" && mapLabel[2][0].getText() == "X"){
            return true;
        }/*start for "O"*/else if(mapLabel[0][0].getText() == "O" && mapLabel[0][1].getText() == "O" && mapLabel[0][2].getText() == "O"){
            return true;
        }else if(mapLabel[1][0].getText() == "O" && mapLabel[1][1].getText() == "O" && mapLabel[1][2].getText() == "O"){
            return true;
        }else if(mapLabel[2][0].getText() == "O" && mapLabel[2][1].getText() == "O" && mapLabel[2][2].getText() == "O"){
            return true;
        }else if(mapLabel[0][0].getText() == "O" && mapLabel[1][0].getText() == "O" && mapLabel[2][0].getText() == "O"){
            return true;
        }else if(mapLabel[0][1].getText() == "O" && mapLabel[1][1].getText() == "O" && mapLabel[2][1].getText() == "O"){
            return true;
        }else if(mapLabel[0][2].getText() == "O" && mapLabel[1][2].getText() == "O" && mapLabel[2][2].getText() == "O"){
            return true;
        }else if(mapLabel[0][0].getText() == "O" && mapLabel[1][1].getText() == "O" && mapLabel[2][2].getText() == "O"){
            return true;
        }else if(mapLabel[0][2].getText() == "O" && mapLabel[1][1].getText() == "O" && mapLabel[2][0].getText() == "O"){
            return true;
        }else{
            return false;
        }
        
    }//end check win
    
    private boolean checkCatsGame(int count){
        this.count = count;
        
        for(int i = 0; i < MAX_ROWS; i++){
            for(int j = 0; j < MAX_COLS; j++){
                if(mapLabel[i][j].getText() == "X" || mapLabel[i][j].getText() == "O"){
                    count++;
                }
            }
        }
        
        if(count == 9){
            return true;
        }else{
            return false;
        }
    }
}// end of FXMLDocumentController class